(ns example)

(defn hello []
  (println "Hello, World!"))
